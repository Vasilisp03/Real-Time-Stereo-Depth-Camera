#ifndef XF_SGBM_ACCEL_CONFIG_H
#define XF_SGBM_ACCEL_CONFIG_H

#include "hls_stream.h"
#include "ap_int.h"
#include "common/xf_common.hpp"
#include "common/xf_utility.hpp"
#include "ap_axi_sdata.h"
#include "common/xf_infra.hpp"
#include "common/xf_axi_io.hpp"
#include "imgproc/xf_sgbm.hpp"

#define HEIGHT 384
#define WIDTH 768
#define MAX_FRAMES 48

#define XF_CV_DEPTH_IN_L 2
#define XF_CV_DEPTH_IN_R 2
#define XF_CV_DEPTH_OUT 2

#define SMALL_PENALTY 20
#define LARGE_PENALTY 40
#define WINDOW_SIZE 5
#define TOTAL_DISPARITY 86
#define PARALLEL_UNITS 48
#define NUM_DIR 4

#define IN_TYPE XF_8UC1
#define OUT_TYPE XF_8UC1
#define NPPCX XF_NPPC1

#define INPUT_PTR_WIDTH 32
#define OUTPUT_PTR_WIDTH 64

// One grayscale pixel per AXI4-Stream beat. Valid for XF_8UC1 + XF_NPPC1.
using VideoAxis = ap_axiu<16, 1, 1, 1>;
using InStream = hls::stream<VideoAxis>;
using OutStream = hls::stream<VideoAxis>;

extern "C" {
void semiglobalbm_accel(InStream& img_in_l,
                        InStream& img_in_r,
                        unsigned char penalty_small,
                        unsigned char penalty_large,
                        OutStream& img_out,
                        int rows,
                        int cols,
                        int frame_count);
}

#endif
