#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <opencv2/opencv.hpp>

#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "xf_sgbm_accel_config.h"

namespace {

constexpr int kFrameCount = 48;

cv::Mat to_grayscale_u8(const cv::Mat& frame) {
    if (frame.empty()) {
        throw std::runtime_error("Decoded an empty video frame");
    }

    cv::Mat gray;

    if (frame.type() == CV_8UC1) {
        gray = frame;
    } else if (frame.type() == CV_8UC3) {
        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
    } else if (frame.type() == CV_8UC4) {
        cv::cvtColor(frame, gray, cv::COLOR_BGRA2GRAY);
    } else {
        throw std::runtime_error(
            "Unsupported decoded frame type: " + std::to_string(frame.type()));
    }

    if (!gray.isContinuous()) {
        gray = gray.clone();
    }

    return gray;
}

} // namespace

int main(int argc, char** argv) {
    try {
        if (argc != 4) {
            std::cerr
                << "Usage: " << argv[0]
                << " <binary.xclbin> <left.mkv> <right.mkv>\n";

            return EXIT_FAILURE;
        }

        static_assert(
            MAX_FRAMES >= kFrameCount,
            "MAX_FRAMES must be at least 48");

        const std::string xclbin_path = argv[1];
        const std::string left_video_path = argv[2];
        const std::string right_video_path = argv[3];
        const std::string output_video_16bit_path =
            "hls_disparity_output_16bit.mkv";

        const std::string output_video_8bit_path =
            "hls_disparity_preview_8bit.mkv";

        cv::VideoCapture left_capture(left_video_path, cv::CAP_FFMPEG);
        cv::VideoCapture right_capture(right_video_path, cv::CAP_FFMPEG);

        if (!left_capture.isOpened()) {
            throw std::runtime_error("Could not open left MKV: " + left_video_path);
        }
        if (!right_capture.isOpened()) {
            throw std::runtime_error("Could not open right MKV: " + right_video_path);
        }

        double fps = left_capture.get(cv::CAP_PROP_FPS);
        const double right_fps = right_capture.get(cv::CAP_PROP_FPS);

        if (!std::isfinite(fps) || fps <= 0.0) {
            fps = 24.0;
        }

        if (std::isfinite(right_fps) && right_fps > 0.0 &&
            std::abs(right_fps - fps) > 0.01) {
            throw std::runtime_error("Left and right MKV frame rates do not match");
        }

        std::vector<cv::Mat> left_frames;
        std::vector<cv::Mat> right_frames;
        left_frames.reserve(kFrameCount);
        right_frames.reserve(kFrameCount);

        int rows = 0;
        int cols = 0;

        for (int frame_index = 0; frame_index < kFrameCount; ++frame_index) {
            cv::Mat left_decoded;
            cv::Mat right_decoded;

            if (!left_capture.read(left_decoded)) {
                throw std::runtime_error(
                    "Left MKV contains fewer than 48 decodable frames");
            }
            if (!right_capture.read(right_decoded)) {
                throw std::runtime_error(
                    "Right MKV contains fewer than 48 decodable frames");
            }

            cv::Mat left_gray = to_grayscale_u8(left_decoded);
            cv::Mat right_gray = to_grayscale_u8(right_decoded);

            if (frame_index == 0) {
                rows = left_gray.rows;
                cols = left_gray.cols;

                std::cerr << "Diagnostic dimensions:\n"
                        << "  Derived video rows: " << rows << '\n'
                        << "  Kernel HEIGHT:      " << HEIGHT << '\n'
                        << "  Derived video cols: " << cols << '\n'
                        << "  Kernel WIDTH:       " << WIDTH << '\n';

                if (rows > HEIGHT || cols > WIDTH) {
                    throw std::runtime_error(
                        "Video frame exceeds kernel HEIGHT/WIDTH");
                }
            }

            if (left_gray.rows != rows || left_gray.cols != cols ||
                right_gray.rows != rows || right_gray.cols != cols) {
                throw std::runtime_error(
                    "All stereo frames must have identical dimensions");
            }

            left_frames.push_back(left_gray.clone());
            right_frames.push_back(right_gray.clone());
        }

        left_capture.release();
        right_capture.release();

        const size_t input_frame_bytes =
            static_cast<size_t>(rows) * static_cast<size_t>(cols) *
            sizeof(uint8_t);

        const size_t input_total_bytes =
            input_frame_bytes * static_cast<size_t>(kFrameCount);

        // INPUT_PTR_WIDTH is 32 bits, so round to four bytes.
        const size_t input_bo_bytes =
            (input_total_bytes + 3u) & ~size_t(3u);

        const size_t output_frame_bytes =
            static_cast<size_t>(rows) * static_cast<size_t>(cols) *
            sizeof(uint16_t);

        const size_t output_total_bytes =
            output_frame_bytes * static_cast<size_t>(kFrameCount);

        // OUTPUT_PTR_WIDTH is 64 bits, so round to eight bytes.
        const size_t output_bo_bytes =
            (output_total_bytes + 7u) & ~size_t(7u);

        xrt::device device(0);
        const auto uuid = device.load_xclbin(xclbin_path);

        xrt::kernel mm2s_l(
            device, uuid, "video_mm2s_batch:{video_mm2s_batch_1}");
        xrt::kernel mm2s_r(
            device, uuid, "video_mm2s_batch:{video_mm2s_batch_2}");
        xrt::kernel sgbm(
            device, uuid, "semiglobalbm_accel:{semiglobalbm_accel_1}");
        xrt::kernel s2mm(
            device, uuid, "video_s2mm_batch:{video_s2mm_batch_1}");

        xrt::bo left_bo(device, input_bo_bytes, mm2s_l.group_id(0));
        xrt::bo right_bo(device, input_bo_bytes, mm2s_r.group_id(0));
        xrt::bo output_bo(device, output_bo_bytes, s2mm.group_id(1));

        auto* left_ptr = left_bo.map<uint8_t*>();
        auto* right_ptr = right_bo.map<uint8_t*>();
        auto* output_ptr = output_bo.map<uint16_t*>();

        std::memset(left_ptr, 0, input_bo_bytes);
        std::memset(right_ptr, 0, input_bo_bytes);
        std::memset(output_ptr, 0, output_bo_bytes);

        for (int frame_index = 0; frame_index < kFrameCount; ++frame_index) {
            const size_t input_offset =
                static_cast<size_t>(frame_index) * input_frame_bytes;

            std::memcpy(
                left_ptr + input_offset,
                left_frames[frame_index].data,
                input_frame_bytes);

            std::memcpy(
                right_ptr + input_offset,
                right_frames[frame_index].data,
                input_frame_bytes);
        }

        const auto end_to_end_begin = std::chrono::steady_clock::now();

        left_bo.sync(XCL_BO_SYNC_BO_TO_DEVICE, input_bo_bytes, 0);
        right_bo.sync(XCL_BO_SYNC_BO_TO_DEVICE, input_bo_bytes, 0);

        xrt::run output_run(s2mm);
        output_run.set_arg(1, output_bo); // arg 0 is connected AXI stream
        output_run.set_arg(2, rows);
        output_run.set_arg(3, cols);
        output_run.set_arg(4, kFrameCount);

        xrt::run sgbm_run(sgbm);
        // args 0, 1, and 4 are connected AXI streams
        sgbm_run.set_arg(
            2, static_cast<unsigned char>(SMALL_PENALTY));
        sgbm_run.set_arg(
            3, static_cast<unsigned char>(LARGE_PENALTY));
        sgbm_run.set_arg(5, rows);
        sgbm_run.set_arg(6, cols);
        sgbm_run.set_arg(7, kFrameCount);

        xrt::run left_run(mm2s_l);
        left_run.set_arg(0, left_bo);
        left_run.set_arg(2, rows); // arg 1 is connected AXI stream
        left_run.set_arg(3, cols);
        left_run.set_arg(4, kFrameCount);

        xrt::run right_run(mm2s_r);
        right_run.set_arg(0, right_bo);
        right_run.set_arg(2, rows); // arg 1 is connected AXI stream
        right_run.set_arg(3, cols);
        right_run.set_arg(4, kFrameCount);

        const auto hardware_begin = std::chrono::steady_clock::now();

        // Start consumers before producers to avoid startup backpressure.
        output_run.start();
        sgbm_run.start();
        left_run.start();
        right_run.start();

        sgbm_run.wait();
        output_run.wait();
        left_run.wait();
        right_run.wait();

        const auto hardware_end = std::chrono::steady_clock::now();

        output_bo.sync(
            XCL_BO_SYNC_BO_FROM_DEVICE,
            output_bo_bytes,
            0);

        const auto end_to_end_end = std::chrono::steady_clock::now();

        // FFV1 in MKV preserves the 16-bit Q8.8 disparity values losslessly.
        /*
 * FFV1 provides lossless video compression.
 *
 * The 16-bit video contains the raw Q8.8 disparity values.
 * The 8-bit video is scaled for viewing in ordinary video players.
 */
        const int ffv1 =
            cv::VideoWriter::fourcc('F', 'F', 'V', '1');

        /*
        * Open the raw 16-bit grayscale video writer.
        */
        const std::vector<int> writer_16bit_params = {
            cv::VIDEOWRITER_PROP_DEPTH, CV_16U,
            cv::VIDEOWRITER_PROP_IS_COLOR, 0
        };

        cv::VideoWriter output_writer_16bit;

        if (!output_writer_16bit.open(
                output_video_16bit_path,
                cv::CAP_FFMPEG,
                ffv1,
                fps,
                cv::Size(cols, rows),
                writer_16bit_params)) {

            throw std::runtime_error(
                "Could not open the 16-bit FFV1 MKV writer. "
                "The installed OpenCV/FFmpeg backend may not support "
                "CV_16UC1 video writing.");
        }

        /*
        * Open the visible 8-bit grayscale preview writer.
        *
        * false means that each video frame is single-channel grayscale,
        * rather than a three-channel BGR frame.
        */
        cv::VideoWriter output_writer_8bit;

        if (!output_writer_8bit.open(
                output_video_8bit_path,
                cv::CAP_FFMPEG,
                ffv1,
                fps,
                cv::Size(cols, rows),
                false)) {

            output_writer_16bit.release();

            throw std::runtime_error(
                "Could not open the 8-bit grayscale FFV1 preview writer.");
        }

        /*
        * The hardware result uses Q8.8 representation:
        *
        *     raw value = actual disparity * 256
        *
        * This scale maps:
        *
        *     disparity 0                   -> preview value 0
        *     disparity TOTAL_DISPARITY - 1 -> preview value 255
        *
        * The preview is only for visualization. It does not preserve the
        * fractional Q8.8 precision.
        */
        const double preview_scale =
            255.0 /
            (256.0 *
            static_cast<double>(TOTAL_DISPARITY - 1));

        for (int frame_index = 0;
            frame_index < kFrameCount;
            ++frame_index) {

            const size_t frame_pixel_offset =
                static_cast<size_t>(frame_index) *
                static_cast<size_t>(rows) *
                static_cast<size_t>(cols);

            /*
            * Raw unsigned 16-bit Q8.8 disparity frame.
            */
            cv::Mat disparity_q8_8(
                rows,
                cols,
                CV_16UC1,
                output_ptr + frame_pixel_offset);

            /*
            * Print the value range to confirm that the accelerator
            * generated nonzero disparity values.
            */
            double raw_min = 0.0;
            double raw_max = 0.0;

            cv::minMaxLoc(
                disparity_q8_8,
                &raw_min,
                &raw_max);

            std::cout
                << "Frame " << frame_index
                << ": raw Q8.8 range "
                << raw_min
                << " to "
                << raw_max
                << ", disparity range "
                << raw_min / 256.0
                << " to "
                << raw_max / 256.0
                << '\n';

            /*
            * Write the raw Q8.8 frame to the 16-bit video.
            */
            output_writer_16bit.write(disparity_q8_8);

            /*
            * Create an 8-bit frame for ordinary video players.
            *
            * convertTo performs:
            *
            *     preview = raw_Q8.8 * preview_scale
            *
            * Values outside 0 to 255 are saturated automatically.
            */
            cv::Mat disparity_preview_u8;

            disparity_q8_8.convertTo(
                disparity_preview_u8,
                CV_8UC1,
                preview_scale);

            /*
            * Write the scaled visualization to the 8-bit video.
            */
            output_writer_8bit.write(disparity_preview_u8);
        }

        output_writer_16bit.release();
        output_writer_8bit.release();

        const double hardware_ms =
            std::chrono::duration<double, std::milli>(
                hardware_end - hardware_begin)
                .count();

        const double end_to_end_ms =
            std::chrono::duration<double, std::milli>(
                end_to_end_end - end_to_end_begin)
                .count();

        std::cout
            << std::fixed
            << std::setprecision(3)
            << "\nProcessed "
            << kFrameCount
            << " stereo frames\n"
            << "Raw 16-bit output: "
            << output_video_16bit_path
            << '\n'
            << "Visible 8-bit preview: "
            << output_video_8bit_path
            << '\n'
            << "16-bit format: FFV1 grayscale, raw Q8.8\n"
            << "8-bit format: FFV1 grayscale, fixed disparity scaling\n"
            << "Frame rate: "
            << fps
            << " FPS\n"
            << "Hardware pipeline time: "
            << hardware_ms
            << " ms\n"
            << "Average hardware time/frame: "
            << hardware_ms / kFrameCount
            << " ms\n"
            << "Transfer + hardware time: "
            << end_to_end_ms
            << " ms\n";

        return EXIT_SUCCESS;
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return EXIT_FAILURE;
    }
}
