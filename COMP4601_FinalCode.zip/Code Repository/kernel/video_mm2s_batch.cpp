#include "xf_sgbm_accel_config.h"

extern "C" {
void video_mm2s_batch(const ap_uint<INPUT_PTR_WIDTH>* src,
                      InStream& video_out,
                      int rows,
                      int cols,
                      int frame_count) {
#pragma HLS INTERFACE m_axi port=src offset=slave bundle=gmem max_read_burst_length=64
#pragma HLS INTERFACE axis port=video_out register
#pragma HLS INTERFACE s_axilite port=src bundle=control
#pragma HLS INTERFACE s_axilite port=rows bundle=control
#pragma HLS INTERFACE s_axilite port=cols bundle=control
#pragma HLS INTERFACE s_axilite port=frame_count bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    const int pixels_per_frame = rows * cols;
    const int total_pixels = pixels_per_frame * frame_count;

pixel_loop:
    for (int i = 0; i < total_pixels; ++i) {
#pragma HLS PIPELINE II=1
        const ap_uint<INPUT_PTR_WIDTH> word = src[i >> 2];
        const int lane = i & 3;
        const int pixel_in_frame = i % pixels_per_frame;
        const int col = pixel_in_frame % cols;

        VideoAxis pixel;
        pixel.data = word.range(lane * 8 + 7, lane * 8);
        pixel.keep = 1;
        pixel.strb = 1;
        pixel.user = (pixel_in_frame == 0); // SOF for every frame
        pixel.last = (col == cols - 1);     // EOL for every line
        pixel.id = 0;
        pixel.dest = 0;
        video_out.write(pixel);
    }
}
}
