#include "xf_sgbm_accel_config.h"

extern "C" {
void video_s2mm_batch(OutStream& video_in,
                      ap_uint<OUTPUT_PTR_WIDTH>* dst,
                      int rows,
                      int cols,
                      int frame_count) {
#pragma HLS INTERFACE axis port=video_in register
#pragma HLS INTERFACE m_axi port=dst offset=slave bundle=gmem max_write_burst_length=64
#pragma HLS INTERFACE s_axilite port=dst bundle=control
#pragma HLS INTERFACE s_axilite port=rows bundle=control
#pragma HLS INTERFACE s_axilite port=cols bundle=control
#pragma HLS INTERFACE s_axilite port=frame_count bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    const int total_pixels = rows * cols * frame_count;
    ap_uint<OUTPUT_PTR_WIDTH> packed = 0;

pixel_loop:
    for (int i = 0; i < total_pixels; ++i) {
#pragma HLS PIPELINE II=1
        const VideoAxis pixel = video_in.read();
        const int lane = i & 3;
        packed.range(lane * 16 + 15, lane * 16) = pixel.data;

        if (lane == 3 || i == total_pixels - 1) {
            dst[i >> 2] = packed;
            packed = 0;
        }
    }
}
}
